# NLP 202 Homework 1

```bash
Name: Kushagra Seth
Email: kuseth@ucsc.edu
Student Id: 2005986
```

## Usage

### Run Experiment

```bash
Run a1_logistic_regression.ipynb and a1_lstm.ipynb seperately on google colab
```

### Github Repo

```bash
https://github.com/Kdotseth7/nlp-202
```